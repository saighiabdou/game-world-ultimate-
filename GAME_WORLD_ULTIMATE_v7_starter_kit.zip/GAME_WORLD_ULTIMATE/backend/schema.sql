-- GAME WORLD ULTIMATE — starter database schema for Supabase (PostgreSQL)
-- Run this in Supabase SQL Editor after creating a new project.
-- IMPORTANT: This schema is a starter foundation, not a complete production backend.

create extension if not exists pgcrypto;

create type public.app_role as enum ('customer', 'seller', 'admin');
create type public.product_kind as enum ('topup', 'membership', 'gift_card', 'game', 'digital');
create type public.order_status as enum ('pending', 'awaiting_payment', 'paid', 'processing', 'completed', 'cancelled', 'refunded');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role public.app_role not null default 'customer',
  preferred_language text not null default 'ar' check (preferred_language in ('ar','fr','en')),
  created_at timestamptz not null default now()
);

create table if not exists public.games (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  platform text not null default 'mobile',
  icon text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  game_id uuid references public.games(id) on delete set null,
  title text not null,
  description text,
  kind public.product_kind not null,
  region text not null default 'global',
  currency text not null default 'USD' check (currency in ('USD','DZD','EUR')),
  price numeric(12,2) check (price is null or price >= 0),
  price_verified_at timestamptz,
  price_source_url text,
  active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.seller_offers (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  seller_id uuid not null references public.profiles(id) on delete cascade,
  seller_sku text,
  region text not null default 'global',
  currency text not null default 'USD' check (currency in ('USD','DZD','EUR')),
  price numeric(12,2) not null check (price >= 0),
  stock_status text not null default 'unknown' check (stock_status in ('available','out_of_stock','unknown')),
  source_url text,
  verified_at timestamptz,
  active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id) on delete restrict,
  status public.order_status not null default 'pending',
  currency text not null default 'USD' check (currency in ('USD','DZD','EUR')),
  subtotal numeric(12,2) not null default 0 check (subtotal >= 0),
  payment_provider text,
  payment_reference text,
  customer_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  offer_id uuid references public.seller_offers(id) on delete set null,
  product_title_snapshot text not null,
  unit_price numeric(12,2) not null check (unit_price >= 0),
  currency text not null default 'USD' check (currency in ('USD','DZD','EUR')),
  quantity integer not null default 1 check (quantity between 1 and 99),
  game_player_id text,
  created_at timestamptz not null default now()
);

create index if not exists products_active_kind_idx on public.products(active, kind);
create index if not exists offers_product_active_idx on public.seller_offers(product_id, active);
create index if not exists orders_customer_created_idx on public.orders(customer_id, created_at desc);

-- Enable Row Level Security. Policies are intentionally conservative.
alter table public.profiles enable row level security;
alter table public.games enable row level security;
alter table public.products enable row level security;
alter table public.seller_offers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- Public can read active catalog data only.
drop policy if exists "active games are readable" on public.games;
create policy "active games are readable" on public.games
for select using (active = true);

drop policy if exists "active products are readable" on public.products;
create policy "active products are readable" on public.products
for select using (active = true);

drop policy if exists "active offers are readable" on public.seller_offers;
create policy "active offers are readable" on public.seller_offers
for select using (active = true);

-- Users can read/update only their own profile (role changes must be controlled server-side).
drop policy if exists "users read own profile" on public.profiles;
create policy "users read own profile" on public.profiles
for select to authenticated using (auth.uid() = id);

drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "users create own profile" on public.profiles;
create policy "users create own profile" on public.profiles
for insert to authenticated with check (auth.uid() = id and role = 'customer');

drop policy if exists "customers read own orders" on public.orders;
create policy "customers read own orders" on public.orders
for select to authenticated using (auth.uid() = customer_id);

drop policy if exists "customers read own order items" on public.order_items;
create policy "customers read own order items" on public.order_items
for select to authenticated using (
  exists (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid())
);

-- Do not add public order-creation or payment-success policies yet.
-- Orders must be created through a trusted server/Edge Function that validates
-- product prices, seller offers, totals, and payment-provider webhooks.
-- Never put the Supabase service-role key in index.html or any public file.
